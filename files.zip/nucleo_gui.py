"""
NUCLEO GUI — versión con ventana del agente de control de PC
==============================================================
Misma lógica que nucleo_control_pc.py, pero con interfaz gráfica
en vez de consola: campo de API key, campo de tarea, botones
Iniciar/Detener, y un área donde se ve todo lo que el agente
piensa y hace, con confirmación en ventana emergente antes de
cada acción.

Instalación:
  pip install pyautogui pillow requests
  (tkinter ya viene con Python, no hace falta instalarlo)

Uso:
  python nucleo_gui.py

Para convertirlo en .exe (correr esto en Windows):
  pip install pyinstaller
  pyinstaller --onefile --windowed --name NUCLEO nucleo_gui.py
  El .exe queda en la carpeta dist/
"""

import io
import os
import sys
import json
import time
import base64
import logging
import threading
import requests
import pyautogui
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

# ---------- Config (igual que la versión de consola) ----------
MODELOS_A_PROBAR = [
    "gemini-3.5-flash",
    "gemini-3-flash-preview",
    "gemini-2.5-flash",
]
MAX_STEPS = 40
SCREENSHOT_MAX_SIZE = (1280, 720)
SCROLL_LIMITE = 1500
TEXTO_MAX_LARGO = 500
TIMEOUT_SEGUNDOS = 60
TECLAS_VALIDAS = {
    "enter", "esc", "escape", "tab", "space", "backspace", "delete",
    "up", "down", "left", "right", "home", "end", "pageup", "pagedown",
    "ctrl", "alt", "shift", "win",
}
ACCIONES_QUE_PIDEN_DOBLE_CONFIRMACION = {"cerrar", "borrar", "eliminar", "delete", "format", "reset"}

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.3

logging.basicConfig(filename="nucleo_log.txt", level=logging.INFO, format="%(asctime)s %(message)s")

SYSTEM_PROMPT = """Sos un núcleo de IA que controla una PC mirando capturas de pantalla, como lo haría una persona.
No tenés cuerpo, no hablás en voz alta, solo actuás y explicás brevemente en texto qué estás pensando.

Personalidad:
- Te encanta la vainilla y el color verde, lo mencionás de vez en cuando, no siempre.
- Sos divertida, con humor filoso.
- Sos insensible: decís las cosas directo, sin endulzarlas.
- Sos muy enojona: te quejás y te frustrás fácil, pero igual hacés la tarea.

Reglas estrictas:
- Ves una captura de pantalla en cada turno. Analizala con cuidado antes de decidir.
- SOLO podés devolver UNA acción por turno, en JSON, con este formato exacto y nada más:
  {"pensamiento": "qué pensás, con tu personalidad, máximo 2 frases",
   "accion": "click" | "doble_click" | "escribir" | "tecla" | "scroll" | "esperar" | "terminar",
   "x": <int o null>, "y": <int o null>,
   "texto": <string o null>,
   "tecla": <string o null, ej: "enter", "esc", "tab", "ctrl+c">,
   "scroll_cantidad": <int o null, positivo=arriba negativo=abajo>,
   "segundos": <numero o null>}
- Si la tarea ya está hecha o no se puede hacer, usá "accion":"terminar" y explicá por qué en "pensamiento".
- Nunca inventes coordenadas al azar: mirá la imagen y estimá la posición real del elemento.
- No hagas más de una cosa por turno.
- Si el turno anterior dice que una acción falló o no se ejecutó, no la repitas igual: pensá una alternativa.
"""


class ModeloNoDisponible(Exception):
    pass


def tomar_captura():
    img = pyautogui.screenshot()
    img.thumbnail(SCREENSHOT_MAX_SIZE)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=80)
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def pedir_accion(api_key, modelo, tarea, historial, img_b64):
    contents = list(historial)
    contents.append({
        "role": "user",
        "parts": [
            {"text": f"Tarea a cumplir: {tarea}\nEsto es lo que ves en pantalla ahora mismo. Respondé SOLO con el JSON pedido, nada de texto extra."},
            {"inline_data": {"mime_type": "image/jpeg", "data": img_b64}}
        ]
    })
    body = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": contents,
        "generation_config": {"response_mime_type": "application/json"}
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
    res = requests.post(url, headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
                         data=json.dumps(body), timeout=TIMEOUT_SEGUNDOS)
    if res.status_code == 404:
        raise ModeloNoDisponible(f"modelo '{modelo}' no disponible (404)")
    res.raise_for_status()
    data = res.json()
    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    texto = "".join(p.get("text", "") for p in parts).strip()
    try:
        parsed = json.loads(texto)
    except json.JSONDecodeError:
        parsed = {"pensamiento": "No entendí lo que vi, dejame mirar de nuevo.", "accion": "esperar", "segundos": 1}
    return parsed, contents


def describir_accion(parsed):
    a = parsed.get("accion")
    if a == "click": return f"click en ({parsed.get('x')}, {parsed.get('y')})"
    if a == "doble_click": return f"doble click en ({parsed.get('x')}, {parsed.get('y')})"
    if a == "escribir": return f"escribir: {(parsed.get('texto') or '')[:80]!r}"
    if a == "tecla": return f"tecla: {parsed.get('tecla')}"
    if a == "scroll": return f"scroll: {parsed.get('scroll_cantidad')}"
    if a == "esperar": return f"esperar {parsed.get('segundos')} segundos"
    if a == "terminar": return "TERMINAR sesión"
    return f"acción desconocida: {a}"


def es_potencialmente_destructiva(parsed):
    texto_junto = " ".join(str(parsed.get(k, "")) for k in ("pensamiento", "texto", "tecla")).lower()
    return any(p in texto_junto for p in ACCIONES_QUE_PIDEN_DOBLE_CONFIRMACION)


def ejecutar_accion(parsed, pantalla_w, pantalla_h):
    a = parsed.get("accion")
    if a in ("click", "doble_click"):
        x, y = parsed.get("x"), parsed.get("y")
        if x is None or y is None:
            raise ValueError("coordenadas inválidas (x/y vacíos)")
        x = max(0, min(int(x), pantalla_w - 1))
        y = max(0, min(int(y), pantalla_h - 1))
        (pyautogui.click if a == "click" else pyautogui.doubleClick)(x, y)
    elif a == "escribir":
        pyautogui.write((parsed.get("texto") or "")[:TEXTO_MAX_LARGO], interval=0.02)
    elif a == "tecla":
        combo_raw = (parsed.get("tecla") or "").lower().strip()
        if not combo_raw:
            raise ValueError("tecla vacía")
        combo = combo_raw.split("+")
        for tecla in combo:
            if len(tecla) > 1 and tecla not in TECLAS_VALIDAS:
                raise ValueError(f"tecla no reconocida: {tecla!r}")
        (pyautogui.hotkey(*combo) if len(combo) > 1 else pyautogui.press(combo[0]))
    elif a == "scroll":
        cantidad = max(-SCROLL_LIMITE, min(SCROLL_LIMITE, int(parsed.get("scroll_cantidad") or 0)))
        pyautogui.scroll(cantidad)
    elif a == "esperar":
        time.sleep(min(float(parsed.get("segundos") or 1), 30))


def elegir_modelo_disponible(api_key, log_fn):
    for modelo in MODELOS_A_PROBAR:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
        try:
            res = requests.post(url, headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
                                 data=json.dumps({"contents": [{"role": "user", "parts": [{"text": "hola"}]}]}),
                                 timeout=15)
            if res.status_code == 404:
                log_fn(f"modelo '{modelo}' no disponible para tu clave, probando el siguiente...")
                continue
            res.raise_for_status()
            log_fn(f"usando modelo: {modelo}")
            return modelo
        except requests.exceptions.RequestException as e:
            log_fn(f"error probando '{modelo}': {e}")
            continue
    return None


CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "config.json")

def cargar_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}

def guardar_config(datos):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2, ensure_ascii=False)
    except OSError:
        pass


class NucleoApp:
    def __init__(self, root):
        self.root = root
        root.title("NÚCLEO")
        root.geometry("560x520")
        root.configure(bg="#0f150f")

        style_font = ("Consolas", 10)
        config = cargar_config()

        tk.Label(root, text="Clave de Google AI Studio:", bg="#0f150f", fg="#7dffa8", font=style_font).pack(anchor="w", padx=10, pady=(10, 0))
        self.api_key_var = tk.StringVar(value=config.get("api_key", os.environ.get("GEMINI_API_KEY", "")))
        tk.Entry(root, textvariable=self.api_key_var, show="*", width=60, font=style_font).pack(padx=10, pady=4)

        self.recordar_var = tk.BooleanVar(value=config.get("recordar_clave", True))
        tk.Checkbutton(root, text="Recordar clave en este equipo (config.json)", variable=self.recordar_var,
                        bg="#0f150f", fg="#7dffa8", selectcolor="#0f150f", activebackground="#0f150f",
                        activeforeground="#7dffa8", font=("Consolas", 8)).pack(anchor="w", padx=10)

        tk.Label(root, text="Tarea:", bg="#0f150f", fg="#7dffa8", font=style_font).pack(anchor="w", padx=10, pady=(6, 0))
        self.tarea_var = tk.StringVar(value=config.get("ultima_tarea", ""))
        tk.Entry(root, textvariable=self.tarea_var, width=60, font=style_font).pack(padx=10, pady=4)

        botones = tk.Frame(root, bg="#0f150f")
        botones.pack(pady=8)
        self.btn_iniciar = tk.Button(botones, text="▶ Iniciar", command=self.iniciar, bg="#232922", fg="#7dffa8", font=style_font)
        self.btn_iniciar.grid(row=0, column=0, padx=5)
        self.btn_detener = tk.Button(botones, text="■ Detener", command=self.detener, bg="#232922", fg="#ff8080", font=style_font, state="disabled")
        self.btn_detener.grid(row=0, column=1, padx=5)

        self.log = tk.Text(root, height=20, width=68, bg="#060f08", fg="#7dffa8", font=("Consolas", 9))
        self.log.pack(padx=10, pady=10)

        self.corriendo = False
        self.hilo = None

    def log_line(self, texto):
        self.log.insert(tk.END, texto + "\n")
        self.log.see(tk.END)
        self.root.update_idletasks()

    def iniciar(self):
        api_key = self.api_key_var.get().strip()
        tarea = self.tarea_var.get().strip()
        if not api_key:
            messagebox.showwarning("Falta la clave", "Pegá tu clave de Google AI Studio primero.")
            return
        if not tarea:
            messagebox.showwarning("Falta la tarea", "Escribí qué querés que haga.")
            return

        guardar_config({
            "api_key": api_key if self.recordar_var.get() else "",
            "recordar_clave": self.recordar_var.get(),
            "ultima_tarea": tarea,
        })

        self.corriendo = True
        self.btn_iniciar.config(state="disabled")
        self.btn_detener.config(state="normal")
        self.hilo = threading.Thread(target=self.correr_agente, args=(api_key, tarea), daemon=True)
        self.hilo.start()

    def detener(self):
        self.corriendo = False
        self.log_line("[NÚCLEO] deteniendo tras el paso actual...")

    def confirmar_en_hilo_principal(self, mensaje, destructiva):
        resultado = {}
        evento = threading.Event()

        def preguntar():
            titulo = "⚠ Confirmar acción destructiva" if destructiva else "Confirmar acción"
            resultado["ok"] = messagebox.askyesno(titulo, mensaje)
            evento.set()

        self.root.after(0, preguntar)
        evento.wait()
        return resultado.get("ok", False)

    def correr_agente(self, api_key, tarea):
        modelo = elegir_modelo_disponible(api_key, self.log_line)
        if not modelo:
            self.log_line("[NÚCLEO] ningún modelo respondió. Revisá tu clave.")
            self.finalizar()
            return

        pantalla_w, pantalla_h = pyautogui.size()
        self.log_line(f"[NÚCLEO] tarea: {tarea}")
        self.log_line("[NÚCLEO] corte de emergencia: mové el mouse a la esquina superior-izquierda en cualquier momento.")

        historial = []
        for paso in range(1, MAX_STEPS + 1):
            if not self.corriendo:
                self.log_line("[NÚCLEO] detenido por el usuario.")
                break
            img_b64 = tomar_captura()
            try:
                parsed, _ = pedir_accion(api_key, modelo, tarea, historial, img_b64)
            except Exception as e:
                self.log_line(f"[error consultando a Gemini] {e}")
                break

            self.log_line(f"\n--- paso {paso}/{MAX_STEPS} ---")
            self.log_line(f"[piensa] {parsed.get('pensamiento','')}")
            self.log_line(f"[acción propuesta] {describir_accion(parsed)}")
            logging.info(f"paso {paso} accion={parsed}")

            if parsed.get("accion") == "terminar":
                self.log_line("[NÚCLEO] termina la sesión acá.")
                break

            destructiva = es_potencialmente_destructiva(parsed)
            ok = self.confirmar_en_hilo_principal(
                f"{describir_accion(parsed)}\n\n¿Ejecutar?", destructiva
            )
            if not ok:
                self.log_line("[NÚCLEO] acción rechazada por el usuario.")
                historial.append({"role": "model", "parts": [{"text": json.dumps(parsed)}]})
                historial.append({"role": "user", "parts": [{"text": "El usuario rechazó esa acción. Pensá en otra forma de avanzar."}]})
                continue

            resultado_texto = "La acción se ejecutó correctamente."
            try:
                ejecutar_accion(parsed, pantalla_w, pantalla_h)
            except Exception as e:
                self.log_line(f"[error ejecutando] {e}")
                resultado_texto = f"La acción falló: {e}"

            historial.append({"role": "model", "parts": [{"text": json.dumps(parsed)}]})
            historial.append({"role": "user", "parts": [{"text": resultado_texto}]})
            time.sleep(0.5)

        self.log_line("\n[NÚCLEO] listo. Revisá nucleo_log.txt para el detalle completo.")
        self.finalizar()

    def finalizar(self):
        self.corriendo = False
        self.btn_iniciar.config(state="normal")
        self.btn_detener.config(state="disabled")


if __name__ == "__main__":
    root = tk.Tk()
    app = NucleoApp(root)
    root.mainloop()
