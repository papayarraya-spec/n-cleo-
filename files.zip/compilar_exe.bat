@echo off
echo ============================================
echo   NUCLEO - compilando a .exe
echo ============================================
echo.

echo [1/5] Comprobando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo Python no esta instalado o no esta agregado al PATH.
    echo Instalalo desde https://www.python.org/downloads/ y asegurate de
    echo tildar "Add Python to PATH" durante la instalacion.
    pause
    exit /b 1
)

if not exist nucleo_gui.py (
    echo.
    echo No se encontro nucleo_gui.py en esta carpeta.
    echo Poné compilar_exe.bat junto a nucleo_gui.py y volve a intentar.
    pause
    exit /b 1
)

echo.
echo [2/5] Comprobando dependencias...
python -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo Instalando dependencias por primera vez, esto puede tardar un poco...
    python -m pip install --upgrade pip
    python -m pip install pyautogui pillow requests pyinstaller
    if errorlevel 1 (
        echo.
        echo ERROR instalando dependencias.
        pause
        exit /b 1
    )
) else (
    echo Ya estaban instaladas, seguimos.
)

echo.
echo [3/5] Limpiando compilaciones anteriores...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist NUCLEO.spec del NUCLEO.spec

echo.
echo [4/5] Compilando NUCLEO.exe (esto puede tardar 1-2 minutos)...
if exist icon.ico (
    echo Usando icono personalizado: icon.ico
    python -m PyInstaller --onefile --windowed --icon=icon.ico --name NUCLEO nucleo_gui.py
) else (
    python -m PyInstaller --onefile --windowed --name NUCLEO nucleo_gui.py
)
if errorlevel 1 (
    echo.
    echo ERROR compilando.
    pause
    exit /b 1
)

if not exist dist\NUCLEO.exe (
    echo.
    echo La compilacion termino pero no se encontro dist\NUCLEO.exe
    echo Revisa los mensajes de arriba para ver que fallo.
    pause
    exit /b 1
)

echo.
echo [5/5] Listo!
echo.
echo Tu .exe esta en: dist\NUCLEO.exe
echo.
echo Abriendo carpeta...
start "" dist
pause
